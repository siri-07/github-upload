# Implement a character type finder
* Refer to the header file char_type.h for writing function
* Upload only char_type.c file to the submitty

## Scoring
* Total score is 15
    * Compilation 2
    * Pass all tests 3
    * Each test case has individual weightage, total is 10

* First 3 submissions are penalty free.
* 4th submission deducts 5 from final score
* 5th submission deducts 10 from final score
* 6th submission deducts 15 from final score

## Deadline for submission
* Refer to the greadable for timelines
* Server is running on UTC and hence it will show 6.5 hours additional to the actual time.

## Testing
* Submitty uses unit testing to test your code.
* You should test your own code and make sure you have tested it code with all possible input types and corner cases.
